# 新增记录
### 支付宝请求支付 2016/3/22

    GET /openApi_AliPay_addPayment
    |-payment_id 需要生成签名支付单的id
    对一个已存在的系统Payemnt生成支付宝签名，返回给客户端
    
    返回数据
    标准结构，在data中存储客户端需求的签名
    
### 添加缴费单 2016/3/22
    POST   /app_addTax
    |-tax_class 缴费类型
    |-tax_month 缴费月份
    通知系统添加一个缴费单
    
    返回数据，标准结构，data中包含有这个缴费单的详细数据
    tax_id:int //系统内部id
    tax_class:int,//类别码
    tax_payment:int,//支付单
    tax_user:int ,//关联用户
    tax_status:int,         //状态码
    tax_create_time:string,//创建时间
    tax_update_time:string,//更新时间
    tax_deadline:string,//截止日期
    tax_pay_time:string,//支付日期
    tax_intro:string //介绍
    
### 微信支付 2016/3/23
    POST /openApi_WeChatPay_addPayment
    |-payment_id 支付单号
    对一个已存在的系统payment生成一个微信预支付单
    
    返回数据：标准结构，data中包含微信支付单的预支付id(prepay_id)
    
### 验证payment是否已经支付 2016/3/23
    GET /app_checkPaymentAlreadyPay
    |-payment_id 传入一个paymentid
    
    返回结构
    标准结构，data中是true，false表示是否已经支付_
    
# 修改记录
    
### 上传真实信息接口 GET  /app_getTrueInfo
     2016/3/22修改
        除了access_token 无需传递任何参数，不符合1.2中的标准查询接口
        
        返回标准结构
        其中data结构
         {
            info_id:int             系统内部id
            info_name:string,       真实姓名
            info_ic_id:string       身份证号//这里有修改，原来名字写错了
        }
    
    

    